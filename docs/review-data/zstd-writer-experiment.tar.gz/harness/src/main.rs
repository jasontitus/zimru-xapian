#[path = "../../../zimru/src/writer/zstd.rs"]
mod writer_codec;
use std::io::{Read,Write};
use std::time::Instant;

fn main() {
    let args:Vec<_>=std::env::args().collect();
    let engine=&args[1];
    let level:i32=args[2].parse().unwrap();
    let workers:usize=args[3].parse().unwrap();
    let source=&args[4];
    let copies:u64=args[5].parse().unwrap();
    let mut data=Vec::new();
    std::fs::File::open(source).unwrap().read_to_end(&mut data).unwrap();
    let n=data.len() as u64 * copies;
    let t=Instant::now();
    let output=std::fs::File::create(&args[6]).unwrap();
    match engine.as_str() {
        "native"=>{
            let mut writer=::zstd::stream::Encoder::new(output,level).unwrap();
            writer.set_pledged_src_size(Some(n)).unwrap();
            if workers>1 {writer.multithread(workers as u32).unwrap();}
            for _ in 0..copies {for chunk in data.chunks(65536){writer.write_all(chunk).unwrap();}}
            writer.finish().unwrap();
        }
        "rust"=>{
            let mut writer=writer_codec::Encoder::new(output,n,level,workers).unwrap();
            for _ in 0..copies {for chunk in data.chunks(65536){writer.write_all(chunk).unwrap();}}
            writer.finish().unwrap();
        }
        _=>unreachable!()
    }
    println!("{} {}",std::fs::metadata(&args[6]).unwrap().len(),t.elapsed().as_nanos());
}
