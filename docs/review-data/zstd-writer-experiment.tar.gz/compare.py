"""Compare native and chosen Rust writer on four archive clusters, hash-checking each frame."""
import csv,hashlib,os,resource,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
source=root/'frames'
exe=root/'harness/target/release/writer-codec-check'
subprocess.run(['cargo','build','--locked','--release','--manifest-path',str(root/'harness/Cargo.toml'),'--target-dir',str(root/'harness/target')],check=True)
with open(root/'reproduced.csv','w') as f:
 w=csv.writer(f)
 w.writerow(['corpus','cluster','level','engine','bytes','cpu_s','elapsed_s'])
 for corpus,sample in [('climate','0000'),('climate','0008'),('nollywood','0000'),('nollywood','0020')]:
  path=source/corpus/(sample+'.raw')
  for level in (19,22):
   for engine in ('native','rust'):
    before=resource.getrusage(resource.RUSAGE_CHILDREN)
    frame=root/'reproduced.zst'
    n,ns=map(int,subprocess.check_output([exe,engine,str(level),'1',path,'1',frame]).split())
    after=resource.getrusage(resource.RUSAGE_CHILDREN)
    digest=hashlib.sha256(subprocess.check_output(['zstd','-dqfc',frame])).digest()
    assert digest==hashlib.sha256(path.read_bytes()).digest()
    w.writerow([corpus,sample,level,engine,n,after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,ns/1e9]);f.flush()
