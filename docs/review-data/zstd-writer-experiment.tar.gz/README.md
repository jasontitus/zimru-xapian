# Zstandard writer checkpoint

All implementation code remains safe Rust. The benchmark uses native Zstandard 1.5.7 for controls and cross-decoding. The uncompressed samples are real Glass-independent content clusters taken from two Wikipedia archives. See fixtures.tsv for source addresses and SHA-256 checksums.

* `large-check.log` records native libzim 9.8.2 extraction plus a full SHA-256 match for a >1 GiB item. This sparse-text sample measures streaming behavior and is especially easy to compress.
* `writer-integration.log`, `abort-tests.log` and `project-writer-oracle.log` record the production writer compatibility and terminal cleanup tests.
* `profile19.txt` samples the original hash-chain match finder on one climate cluster. `codec-summary.txt` covers the original independent 2 MiB job prototype. Times there are median wall milliseconds from a shared host.
* `window-check.log` compares an intermediate production writer with 8 MiB jobs and 4 MiB history at high levels against native Zstandard. See sample labels for adjacent article text and the same 3 MiB article text duplicated. The subsequent change also enables 8 MiB jobs for single-worker level 3+.
* `budget.csv` compares reducing only the hash-chain search budget, using four real clusters at each of levels 19 and 22. The native rows are also controls for `tree.csv`. Neither the div2, div4 nor div8 budget was adopted.
* `optimal-tree.patch` is the separately testable encoding experiment, using a bounded binary tree to search matches for dictionary-free optimal parsing. It preserves the per-level search parameters. Apply from the root of the zimru source checkpoint using `git apply optimal-tree.patch`. Frames with a dictionary retain the upstream hash-chain path.
* `tree.csv` records encoded size, child CPU seconds and elapsed seconds on the same four real clusters, all native decoded and hash-checked. There is one sample per condition. CPU timings include process startup and file I/O. Thread and CPU contention can affect timing, particularly elapsed time.

To reproduce the small-cluster experiments, fetch the archives in fixtures.tsv, set ZIM_FIXTURE_DIR, run extract.py, and run the supplied command harness from this directory (its source include resolves the supplied zimru checkout).

Place this directory next to a source checkout named `zimru`. Requires Python 3, Rust/Cargo, a C compiler for the native reference, and the zstd CLI. In this directory run `ZIM_FIXTURE_DIR=/path/to/fixtures python3 extract.py`, then `python3 compare.py`. Optionally apply the experiment patch to a fresh copy of the checkout before running compare.py again. The harness writes reproduced.csv. The main project remains native-code-free for production; the comparison harness links the native reference for validation.
