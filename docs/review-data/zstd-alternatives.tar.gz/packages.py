import urllib.request,json,concurrent.futures,time
from pathlib import Path
names=['zstd-pure-rs','structured-zstd','zstdx','oxiarc-zstd','ruzstd','ms-compress-ruzstd','yolowzstd','zstd-rs','zstd','zstd-native','cosmoz']
def get(n):
 with urllib.request.urlopen(urllib.request.Request('https://crates.io/api/v1/crates/'+n,headers={'User-Agent':'zimru-compatibility-review/0.1'}),timeout=15) as f:d=json.load(f)
 c=d['crate'];v=d['versions'][0]
 return (n,{k:c.get(k) for k in ['created_at','updated_at','max_version','repository','downloads','recent_downloads']}|{'latest_checksum':v['checksum'],'releases':len(d['versions'])})
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as e:
 a=dict(e.map(get,names));Path('registry-metadata.json').write_text(json.dumps(a,indent=2))
