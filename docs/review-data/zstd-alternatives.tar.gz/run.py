import os
from pathlib import Path
import subprocess as sp,sys,time,hashlib,json,os
root=Path(__file__).resolve().parent
NAMES=['zstd-native','zstd-rs','cosmoz','yolowzstd','oxiarc-zstd','ms-compress-ruzstd','structured-zstd','zstdx','zstd-pure-rs','ruzstd']
frames=sorted(Path(os.environ.get('ZIM_CODEC_FRAMES','frames')).glob('*/*.zst'))
if len(sys.argv)>1:NAMES=sys.argv[1:]
probe=root/'target/release/codec-alternatives'
def run(cmd,timeout):return sp.run([str(c) for c in cmd],capture_output=True,timeout=timeout)
def output(r):return (r.stderr.decode(errors='replace').strip() or r.stdout.decode(errors='replace').strip())[-265:]
def save(): (root/'results.json').write_text(json.dumps(results,indent=2))
results=json.loads((root/'results.json').read_text()) if (root/'results.json').exists() else {}
for name in NAMES:
 d=results[name]={'decode':{},'encode':{}}
 for f in frames:
  tag=str(f.relative_to(f.parents[1]))
  a=run([probe,name,'dec',f,f.with_suffix('.raw'),1],35)
  d['decode'][tag]=[int(x) for x in a.stdout.split()] if a.returncode==0 else {'error':output(a)}
 save()
 print('decode',name,sum(isinstance(y,list) for y in d['decode'].values()),len(frames),flush=True)
for name in NAMES:
 d=results[name]
 for level in ([1] if name in ('ruzstd','ms-compress-ruzstd') else ([1,12,22] if name=='cosmoz' else [3,19])):
  for raw in [frames[0].with_suffix('.raw'), next(f for f in frames if 'nollywood' in str(f)).with_suffix('.raw')]:
   key=str(raw.relative_to(raw.parents[1]))+'@'+str(level);out=root/'encoded.tmp'
   try:
    a=run([probe,name,'enc',raw,level,1,out],60)
    if a.returncode: rec={'error':output(a)}
    else:
     ref=run(['zstd','-qdc',out],20)
     rec={'bytes_and_ns':[int(x) for x in a.stdout.split()],'native_match':ref.returncode==0 and ref.stdout==raw.read_bytes()}
   except sp.TimeoutExpired:rec={'timeout':60}
   d['encode'][key]=rec;save();print('encode',name,key,rec,flush=True)
results['libzstd']={'encode':{}}
for level in [1,3,19]:
 for raw in [frames[0].with_suffix('.raw'),next(f for f in frames if 'nollywood' in str(f)).with_suffix('.raw')]:
  key=str(raw.relative_to(raw.parents[1]))+'@'+str(level);start=time.perf_counter_ns()
  a=run(['zstd','--single-thread','--no-check','-qfc','-'+str(level),raw],90)
  assert a.returncode==0
  results['libzstd']['encode'][key]={'bytes_and_ns':[raw.stat().st_size,len(a.stdout),time.perf_counter_ns()-start]}
save()
