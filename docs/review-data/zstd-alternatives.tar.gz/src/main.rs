use std::{fs,io::Read,path::Path,time::Instant};
type R = Result<Vec<u8>, String>;
fn err(t:impl std::fmt::Debug)->String{ format!("{t:?}") }
fn streamed(r:impl Read,cap:usize)->R{let mut out=Vec::new();r.take(cap as u64+1).read_to_end(&mut out).map_err(err)?; if out.len()>cap{return Err("over limit".into())} Ok(out)}
fn decode(name:&str,b:&[u8],cap:usize)->R {
match name{
#[cfg(feature="zstd-native")] "zstd-native"=>{let mut out=vec![0;cap];let n=zstd_native::decompress_to_slice(b,&mut out).map_err(err)?;out.truncate(n);Ok(out)}
#[cfg(feature="cosmoz")] "cosmoz"=>cosmoz::decompress_with(b,&cosmoz::DecompressOptions{verify_checksum:true,max_output_size:Some(cap)}).map_err(err),
#[cfg(feature="zstd-rs")] "zstd-rs"=>{let mut o=Vec::new();zstd_rs::Decompressor::new().decompress(b,None,cap,&mut o).map_err(err)?;Ok(o)}
#[cfg(feature="zstd-pure-rs")] "zstd-pure-rs"=>{use zstd_pure_rs::prelude::*; let mut o=vec![0;cap];let n=ZSTD_decompress(&mut o,b); if ZSTD_isError(n){return Err(format!("{n}"))}o.truncate(n); Ok(o)}
#[cfg(feature="structured-zstd")] "structured-zstd"=>streamed(structured_zstd::decoding::StreamingDecoder::new(b),cap),
#[cfg(feature="zstdx")] "zstdx"=>zstdx::bulk::decompress(b,cap).map_err(err),
#[cfg(feature="oxiarc-zstd")] "oxiarc-zstd"=>oxiarc_zstd::decompress_multi_frame_with_limit(b,cap).map_err(err),
#[cfg(feature="ruzstd")] "ruzstd"=>streamed(ruzstd::decoding::StreamingDecoder::new(b).map_err(err)?,cap),
#[cfg(feature="ms-compress-ruzstd")] "ms-compress-ruzstd"=>streamed(ms_compress_ruzstd::decoding::StreamingDecoder::new(b).map_err(err)?,cap),
#[cfg(feature="yolowzstd")] "yolowzstd"=>yolowzstd::decompress(b,cap).map_err(err),
_=>Err("unknown codec".into())}}
fn encode(name:&str,b:&[u8],lev:i32)->R{
match name{
#[cfg(feature="zstd-native")] "zstd-native"=>zstd_native::compress(b,lev).map_err(err),
#[cfg(feature="cosmoz")] "cosmoz"=>cosmoz::compress_with(b,&cosmoz::CompressOptions{level:lev as u8,checksum:false}).map_err(err),
#[cfg(feature="zstd-rs")] "zstd-rs"=>{let mut o=Vec::new();let mut c=zstd_rs::Compressor::new(zstd_rs::CompressionConfig{level:lev,..zstd_rs::CompressionConfig::DEFAULT}).map_err(err)?;c.compress(b,None,&mut o).map_err(err)?;Ok(o)}
#[cfg(feature="zstd-pure-rs")] "zstd-pure-rs"=>{use zstd_pure_rs::prelude::*; let mut o=vec![0;ZSTD_compressBound(b.len())];let n=ZSTD_compress(&mut o,b,lev);if ZSTD_isError(n){return Err(format!("{n}"))}o.truncate(n); Ok(o)}
#[cfg(feature="structured-zstd")] "structured-zstd"=> Ok(structured_zstd::encoding::compress_to_vec(b,structured_zstd::encoding::CompressionLevel::from_level(lev))),
#[cfg(feature="zstdx")] "zstdx"=>Ok(zstdx::bulk::compress(b,zstdx::Level::from_zstd(lev))),
#[cfg(feature="oxiarc-zstd")] "oxiarc-zstd"=>oxiarc_zstd::compress_with_level(b,lev).map_err(err),
#[cfg(feature="ruzstd")] "ruzstd" if lev==1=> Ok(ruzstd::encoding::compress_to_vec(b,ruzstd::encoding::CompressionLevel::Fastest)),
#[cfg(feature="ms-compress-ruzstd")] "ms-compress-ruzstd" if lev==1=> Ok(ms_compress_ruzstd::encoding::compress_to_vec(b,ms_compress_ruzstd::encoding::CompressionLevel::Fastest)),
#[cfg(feature="yolowzstd")] "yolowzstd"=> Ok(yolowzstd::compress(b,lev)),
_=>Err("unsupported level".into())}}
fn main(){let a:Vec<_>=std::env::args().collect();let n=&a[1]; let inpath=Path::new(&a[3]);let b=fs::read(inpath).unwrap();let reps:usize=a[5].parse().unwrap(); if a[2]=="dec"{let expected=fs::read(&a[4]).unwrap();let start=Instant::now();for _ in 0..reps{let out=decode(n,&b,expected.len()).unwrap();assert_eq!(out.len(),expected.len());assert!(out==expected);}println!("{} {} {}",expected.len(),b.len(),start.elapsed().as_nanos());}else{let lev:i32=a[4].parse().unwrap();let start=Instant::now();let mut o=Vec::new();for _ in 0..reps{o=encode(n,&b,lev).unwrap();}let tm=start.elapsed().as_nanos();fs::write(&a[6],&o).unwrap();println!("{} {} {}",b.len(),o.len(),tm);}}
