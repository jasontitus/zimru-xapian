import os
from pathlib import Path
import json,subprocess as sp, struct,tempfile
from runpy import run_path
root=Path(__file__).resolve().parent
n=['zstd-rs','zstd-native','cosmoz','yolowzstd','oxiarc-zstd','ms-compress-ruzstd','structured-zstd','zstdx','zstd-pure-rs','ruzstd']
raw=(Path(os.environ.get('ZIM_CODEC_FRAMES','frames'))/'climate'/'0000.raw').read_bytes()[:69001]
with tempfile.TemporaryDirectory() as td:
 tmp=Path(td)
 (tmp/'src').write_bytes(raw)
 f=sp.run(['zstd','-qc','--check','-3',tmp/'src'],check=True,capture_output=True).stdout
 unknown=sp.run(['zstd','-qc','--check','-3','-'],input=raw,check=True,capture_output=True).stdout
 assert unknown[4]&32==0 and (unknown[4]>>6)==0
 skip=struct.pack('<II',0x184d2a5f,5)+b'hello'
 cases={'checksum':(f,raw),'no-content-size':(unknown,raw),'two-frames':(f+unknown,raw*2),'skippable-between':(f+skip+unknown,raw*2)}
 m={}
 for k,(data,expected) in cases.items():
  assert sp.run(['zstd','-qdc'],input=data,capture_output=True,check=True).stdout==expected
  (tmp/'in').write_bytes(data);(tmp/'raw').write_bytes(expected)
  m[k]={}
  for name in n:
   p=sp.run([root/'target/release/codec-alternatives',name,'dec',tmp/'in',tmp/'raw','1'],capture_output=True)
   m[k][name]=p.returncode==0
 print(json.dumps(m,indent=2))
