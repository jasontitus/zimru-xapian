"""Extract each Zstandard cluster and its native-decoded bytes from the two oracle archives."""
from pathlib import Path
import os,struct,subprocess
for p in sorted(Path(os.environ['ZIM_FIXTURE_DIR']).glob('wikipedia_en_*.zim')):
 data=p.read_bytes()
 count=struct.unpack_from('<I',data,28)[0]; table=struct.unpack_from('<Q',data,48)[0]
 offs=struct.unpack_from(f'<{count}Q',data,table)
 for i,(a,b) in enumerate(zip(offs,offs[1:]+(struct.unpack_from('<Q',data,72)[0],))):
  if data[a]&15!=5: continue
  file=Path('frames')/p.name.split('_')[2]/f'{i:04d}.zst';file.parent.mkdir(exist_ok=True,parents=True);file.write_bytes(data[a+1:b])
  subprocess.run(['zstd','-fdq',file,'-o',file.with_suffix('.raw')],check=True)
