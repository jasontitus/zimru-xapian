use std::{env, time::Instant};
fn main(){
 let args:Vec<_>=env::args().collect(); let reps:usize=args[2].parse().unwrap(); let a=zimru::Archive::open(&args[1]).unwrap(); let start=Instant::now(); 
 let mut total=0u64;
 for _ in 0..reps{for i in 0..a.cluster_count(){let c=a.cluster_uncached(i).unwrap(); for b in 0..c.blob_count(){total+=c.blob(b).unwrap().len() as u64;}}}
 println!("{} {total}",start.elapsed().as_nanos());
}
