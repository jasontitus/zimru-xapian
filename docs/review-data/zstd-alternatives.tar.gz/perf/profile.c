#define _GNU_SOURCE
#include <link.h>
#include <sys/types.h>
#include <stdint.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
static unsigned short *hist;
static uintptr_t off,base;
static size_t count;
static int mainseg(struct dl_phdr_info *p,size_t size,void*ctx){
 if (*p->dlpi_name)return 0;
 base=p->dlpi_addr;
 for(unsigned i=0;i<p->dlpi_phnum;i++){
  const ElfW(Phdr) *ph=p->dlpi_phdr+i;
  if(ph->p_type!=PT_LOAD || !(ph->p_flags&PF_X)) continue;
  off=base+ph->p_vaddr;count=(ph->p_memsz+1)/2;hist=calloc(count,2);
  if(hist)profil(hist,2*count,off,65536);return 1;
 }
 return 0;
}
__attribute__((constructor)) static void start(void){ dl_iterate_phdr(mainseg,0); }
__attribute__((destructor)) static void finish(void){
 profil(NULL,0,0,0);if(!hist)return;
 const char *name=getenv("SAMPLES_FILE");FILE *f=fopen(name?name:"samples.tsv","w");if(!f)return;
 for(size_t i=0;i<count;i++)if(hist[i])fprintf(f,"%lx %u\n",(unsigned long)(off-base+2*i),hist[i]);fclose(f);free(hist);
}
