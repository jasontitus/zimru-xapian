samples 448 

functions
   73 core::ptr::copy::<u8>
   68 decode::sequences::decode
   60 <alloc::vec::Vec<decode::seqtable::SeqEntry> as core::ops::index::Index<usize>>::index
   53 <bits::RevReader>::peek
   28 core::ptr::copy_nonoverlapping::<u8>
   23 <decode::execute::Exec>::sequence
   18 <bits::RevReader>::refill
   15 decode::execute::copy_match
   12 <decode::execute::Exec>::room
    9 <usize as core::slice::index::SliceIndex<[decode::seqtable::SeqEntry]>>::index
    8 <usize>::checked_add
    7 <huf::fast::Stream>::decode
    7 <usize>::checked_sub
    6 core::slice::index::try_into_slice_range
    6 fse::spread
    5 <usize as core::cmp::Ord>::min
    5 <alloc::raw_vec::RawVecInner>::non_null::<u8>
    5 decode::sequences::state_update
    4 bits::load
    4 core::intrinsics::unlikely
    3 <alloc::vec::Vec<decode::seqtable::SeqEntry>>::push
    3 fse::dtable::build_with::<<decode::seqtable::SeqTable>::build::{closure#0}>
    2 <zimru::cluster::Cluster>::blob_range
    2 <core::ptr::non_null::NonNull<u8> as core::cmp::PartialEq>::eq
    2 <huf::dtable::HufDTable>::rebuild
    2 <alloc::vec::Vec<u8>>::as_mut_slice
    2 <usize as core::cmp::PartialOrd>::lt
    2 huf::weights::complete
    1 <core::result::Result<core::ops::range::Range<usize>, zimru::error::Error> as core::ops::try_trait::Try>::branch
    1 <core::slice::iter::IterMut<huf::dtable::HEntry> as core::iter::traits::iterator::Iterator>::next

lines
   73 ptr/mod.rs:665
   60 slice/index.rs:?
   37 bits.rs:138
   28 ptr/mod.rs:574
   26 decode/execute.rs:?
   19 decode/sequences.rs:99
   16 bits.rs:139
   12 decode/sequences.rs:?
   11 decode/sequences.rs:113
   10 decode/sequences.rs:108
    9 slice/index.rs:238
    8 num/uint_macros.rs:968
    7 num/uint_macros.rs:1122
    7 decode/execute.rs:48
    6 huf/fast.rs:46
    6 raw_vec/mod.rs:635
    6 decode/execute.rs:73
    6 fse/mod.rs:?
    5 bits.rs:?
    5 decode/execute.rs:45
    5 cmp.rs:2311
    5 decode/execute.rs:142
    5 decode/sequences.rs:53
    4 bits.rs:179
    4 bits.rs:154
    4 bits.rs:156
    4 decode/sequences.rs:135
    4 intrinsics/mod.rs:?
    3 bits.rs:150
    3 ptr/mod.rs:?
