samples 344 

functions
   57 decode::sequences::decode
   50 core::ptr::copy::<u8>
   40 <bits::RevReader>::peek
   29 <alloc::vec::Vec<decode::seqtable::SeqEntry> as core::ops::index::Index<usize>>::index
   25 <decode::execute::Exec>::sequence
   17 core::ptr::copy_nonoverlapping::<u8>
   14 <bits::RevReader>::refill
   14 decode::execute::copy_match
   10 <usize as core::slice::index::SliceIndex<[decode::seqtable::SeqEntry]>>::index
   10 <usize>::checked_add
    9 <decode::execute::Exec>::room
    9 fse::spread
    8 <alloc::vec::Vec<decode::seqtable::SeqEntry>>::push
    5 <usize as core::cmp::PartialOrd>::lt
    5 <usize as core::cmp::Ord>::min
    3 <huf::fast::Stream>::decode
    3 <bits::RevReader>::read
    3 <usize>::checked_sub
    3 core::slice::index::try_into_slice_range
    3 decode::sequences::state_update
    3 <i16 as core::cmp::PartialOrd>::lt
    2 <core::slice::iter::IterMut<huf::dtable::HEntry> as core::iter::traits::iterator::Iterator>::next
    2 <alloc::raw_vec::RawVecInner>::non_null::<u8>
    2 huf::weights::complete
    1 <std::sys::sync::once::futex::Once>::is_completed
    1 <[u8]>::copy_within::<core::ops::range::Range<usize>>
    1 <core::ptr::non_null::NonNull<u8> as core::cmp::PartialEq>::eq
    1 <huf::dtable::HufDTable>::rebuild
    1 huf::fast::four
    1 huf::fast::load

lines
   50 ptr/mod.rs:665
   31 bits.rs:138
   29 slice/index.rs:?
   26 decode/execute.rs:?
   17 ptr/mod.rs:574
   15 decode/sequences.rs:99
   10 slice/index.rs:238
   10 num/uint_macros.rs:968
    9 bits.rs:139
    8 cmp.rs:2215
    8 vec/mod.rs:963
    7 decode/sequences.rs:?
    7 decode/sequences.rs:113
    6 decode/sequences.rs:135
    6 decode/execute.rs:142
    5 decode/sequences.rs:106
    5 cmp.rs:2311
    5 fse/mod.rs:?
    4 bits.rs:150
    4 bits.rs:?
    4 ptr/mod.rs:?
    4 decode/sequences.rs:108
    4 decode/execute.rs:45
    4 decode/execute.rs:48
    3 bits.rs:154
    3 bits.rs:131
    3 num/uint_macros.rs:1122
    3 decode/execute.rs:67
    3 decode/execute.rs:73
    3 raw_vec/mod.rs:635
