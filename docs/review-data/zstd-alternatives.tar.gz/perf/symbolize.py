import collections,subprocess as sp,sys
from pathlib import Path
binary=Path(sys.argv[1]); inp=Path(sys.argv[2]); data=[(str(a),int(n)) for a,n in map(str.split,inp.read_text().splitlines())]
x=sp.run(['addr2line','-C','-f','-e',binary],input='\n'.join(a for a,n in data)+'\n',capture_output=True,text=True,check=True).stdout.splitlines()
groups=collections.Counter();lines=collections.Counter()
for (_,n),fn,loc in zip(data,x[::2],x[1::2]): 
 fn=fn.replace('zstd_rs::','')
 groups[fn]+=n;lines[loc.split('/src/')[-1]]+=n
def show(c):return '\n'.join(f'{n:5} {v}' for v,n in c.most_common(30))
print('samples',sum(groups.values()),'\n\nfunctions\n'+show(groups)+'\n\nlines\n'+show(lines))
