from pathlib import Path
import subprocess as sp, json, resource, statistics as st,sys
p=Path(__file__).resolve().parent
cases=sys.argv[3:]
report={}
for case in cases:
 data={'native':[],'rust':[]}
 for name in ('native','rust','rust','native')*3:
  cmd= [sys.argv[1],case] if name=='native' else [sys.argv[2],case,'1']
  t=resource.getrusage(resource.RUSAGE_CHILDREN);v=sp.run(cmd,check=True,capture_output=True);u=resource.getrusage(resource.RUSAGE_CHILDREN)
  ns,size=map(int,v.stdout.split())
  data[name].append({'ms_cpu':1000*(u.ru_stime+u.ru_utime-t.ru_stime-t.ru_utime),'ms_elapsed':ns/1e6,'bytes':size})
 report[Path(case).name]=data
 print(Path(case).name,{k:tuple(round(st.median(i[m] for i in d),2) for m in ('ms_cpu','ms_elapsed')) for k,d in data.items()},flush=True)
(p/'native-vs-rust.json').write_text(json.dumps(report,indent=2))
