from pathlib import Path
p=Path('vendor/zstd-rs/src/decode/sequences.rs');s=p.read_text()
s=s.replace('Kind, SeqEntry, SeqTable','Kind, SeqTable')
a=s.index('#[inline(always)]\nfn state_update');b=s.index('/// Decodes the sequences',a)
s=s[:a]+'''#[inline(always)]
fn low_bits(value: u64, width: u8) -> u32 {
    value as u32 & ((1u32 << width) - 1)
}

'''+s[b:]
a=s.index('        let of_value = ofe.base');b=s.index('        let offset = if',a)
s=s[:a]+'''        // Group adjacent fields. A refill gives 57 bits (or zero padding
        // at the physical start), enough for each group by the RFC limits.
        let pair = r.read(u32::from(ofe.add_bits + mle.add_bits));
        let of_value = ofe.base + (pair >> mle.add_bits) as u32;
        let ml = mle.base + low_bits(pair, mle.add_bits);
        r.refill();
        let ll = if i + 1 < n {
            let state_bits = lle.nb_bits + mle.nb_bits + ofe.nb_bits;
            let packed = r.read(u32::from(lle.add_bits + state_bits));
            of_s = ofe.next as usize + low_bits(packed, ofe.nb_bits) as usize;
            let higher = packed >> ofe.nb_bits;
            ml_s = mle.next as usize + low_bits(higher, mle.nb_bits) as usize;
            ll_s = lle.next as usize + low_bits(higher >> mle.nb_bits, lle.nb_bits) as usize;
            lle.base + (packed >> state_bits) as u32
        } else {
            lle.base + r.read(u32::from(lle.add_bits)) as u32
        };
'''+s[b:]
a=s.index('        if i + 1 < n {\n            ll_s = state_update');b=s.index('\n    }',a);s=s[:a]+s[b:];p.write_text(s)
