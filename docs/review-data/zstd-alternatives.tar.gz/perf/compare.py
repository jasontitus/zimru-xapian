from pathlib import Path
import subprocess as sp, sys, resource, json, statistics as st,os
base=Path(__file__).resolve().parent
fixtures={'zh':os.environ.get('ZIM_CHEMISTRY','/workspace/zimru/zim-cache/wikipedia_zh_chemistry_mini.zim'),'nollywood':os.environ.get('ZIM_NOLLYWOOD','/tmp/zim-reference/fixtures/wikipedia_en_nollywood_maxi_2026-10.zim')}
a,b=sys.argv[1:3];report={}
for label,p in fixtures.items():
 d=report[label]={a:[],b:[]};tot=None
 for name in (a,b,b,a,b,a,a,b):
  r0=resource.getrusage(resource.RUSAGE_CHILDREN);r=sp.run([str(base/name),p,'3'],capture_output=True,check=True);r1=resource.getrusage(resource.RUSAGE_CHILDREN);wall,count=map(int,r.stdout.split())
  cpu=((r1.ru_utime-r0.ru_utime)+(r1.ru_stime-r0.ru_stime))*1000/3
  d[name].append({'cpu_ms':cpu,'elapsed_ms':wall/3e6,'bytes_per_iter':count//3})
  if tot is None:tot=count
  assert count==tot
 print(label,[(name,round(st.median(v['cpu_ms'] for v in vals),2)) for name,vals in d.items()],flush=True)
(base/(a+'-vs-'+b+'.json')).write_text(json.dumps(report,indent=2))
