from pathlib import Path
p=Path('vendor/zstd-rs/src/decode/seqtable.rs');s=p.read_text().replace('use alloc::vec::Vec;','use alloc::boxed::Box;').replace('#[derive(Clone, Debug, Default)]\npub struct SeqTable','#[derive(Clone, Debug)]\npub struct SeqTable').replace('    pub e: Vec<SeqEntry>,','    e: Box<[SeqEntry; 1 << dtable::MAX_LOG]>,').replace('impl SeqTable {','''impl Default for SeqTable {
    fn default() -> Self {
        Self { e: Box::new([SeqEntry::default(); 1 << dtable::MAX_LOG]), log: 0 }
    }
}
impl SeqTable {
    /// The FSE transition produces a state within the table accuracy log,
    /// which is checked on construction and is at most nine bits.
    #[inline(always)]
    pub fn entry(&self, state: usize) -> SeqEntry {
        self.e[state & ((1 << dtable::MAX_LOG) - 1)]
    }
''').replace('        self.e.clear();\n        let e = &mut self.e;', '        let mut i = 0;').replace('            e.push(SeqEntry { base, next: d.base, nb_bits: d.nb_bits, add_bits });', '            self.e[i] = SeqEntry { base, next: d.base, nb_bits: d.nb_bits, add_bits };\n            i += 1;').replace('        self.e.clear();\n        self.e.push(SeqEntry { base, next: 0, nb_bits: 0, add_bits });', '        self.e[0] = SeqEntry { base, next: 0, nb_bits: 0, add_bits };')
p.write_text(s)
p=Path('vendor/zstd-rs/src/decode/sequences.rs');s=p.read_text().replace('ll_t.e[ll_s], of_t.e[of_s], ml_t.e[ml_s]', 'll_t.entry(ll_s), of_t.entry(of_s), ml_t.entry(ml_s)');p.write_text(s)
