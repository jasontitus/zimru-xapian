from pathlib import Path
p=Path('vendor/zstd-rs/src/bits.rs');s=p.read_text();i=s.index('    /// Returns the next');s=s[:i]+'''    /// Read three adjacent fields from one loaded window, padding with zeros
    /// at the physical start of the stream just like individual reads.
    #[inline(always)]
    pub(crate) fn read_three(&mut self, a: u32, b: u32, c: u32) -> (u32, u32, u32) {
        let bits = self.read(a + b + c);
        ((bits >> (b + c)) as u32, ((bits >> c) as u32) & ((1u32 << b) - 1),
          bits as u32 & ((1u32 << c) - 1))
    }

'''+s[i:];p.write_text(s)
p=Path('vendor/zstd-rs/src/decode/sequences.rs');s=p.read_text();a=s.index('        // Two refills');b=s.index('        let offset = if',a)
s=s[:a]+'''        r.refill();
        let (a, b, c) = (u32::from(ofe.add_bits), u32::from(mle.add_bits), u32::from(lle.add_bits));
        let (of_bits, ml_bits, ll_bits) = if a + b + c <= 57 {
            r.read_three(a, b, c)
        } else {
            let of = r.read(a) as u32;
            let ml = r.read(b) as u32;
            r.refill();
            (of, ml, r.read(c) as u32)
        };
        let of_value = ofe.base + of_bits;
        let ml = mle.base + ml_bits;
        let ll = lle.base + ll_bits;
'''+s[b:]
a=s.index('            ll_s = state_update');b=s.index('\n        }',a)
s=s[:a]+'''            r.refill();
            let (l, m, o) = r.read_three(lle.nb_bits as u32, mle.nb_bits as u32, ofe.nb_bits as u32);
            ll_s = lle.next as usize + l as usize;
            ml_s = mle.next as usize + m as usize;
            of_s = ofe.next as usize + o as usize;'''+s[b:]
s=s.replace('Kind, SeqEntry, SeqTable','Kind, SeqTable')
a=s.index('#[inline(always)]\nfn state_update');b=s.index('/// Decodes the sequences',a);s=s[:a]+s[b:]
p.write_text(s)
