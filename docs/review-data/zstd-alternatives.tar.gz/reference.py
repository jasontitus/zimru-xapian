import os
import ctypes as C,json,time,statistics as st
from pathlib import Path
from ctypes.util import find_library
z=C.CDLL(find_library('zstd'))
S=C.c_size_t;P=C.c_void_p;I=C.c_int
z.ZSTD_compressBound.argtypes=[S];z.ZSTD_compressBound.restype=S
z.ZSTD_compress.argtypes=[P,S,P,S,I];z.ZSTD_compress.restype=S
z.ZSTD_decompress.argtypes=[P,S,P,S];z.ZSTD_decompress.restype=S
z.ZSTD_isError.argtypes=[S];z.ZSTD_isError.restype=C.c_uint
z.ZSTD_versionString.restype=C.c_char_p
root=Path(os.environ.get('ZIM_CODEC_FRAMES','frames'));frames=sorted(root.glob('*/*.zst'));out={'version':z.ZSTD_versionString().decode(),'decode':{},'encode':{}}
for f in frames:
 inp=f.read_bytes();raw=f.with_suffix('.raw').read_bytes();buf=C.create_string_buffer(len(raw))
 t=time.process_time_ns();n=z.ZSTD_decompress(buf,len(raw),inp,len(inp));dt=time.process_time_ns()-t;assert n==len(raw) and buf.raw==raw
 out['decode'][str(f.relative_to(root))]=[len(raw),len(inp),dt]
for f in [frames[0],next(f for f in frames if 'nollywood' in str(f))]:
 raw=f.with_suffix('.raw').read_bytes();cap=z.ZSTD_compressBound(len(raw));buf=C.create_string_buffer(cap)
 for level in [1,3,19,22]:
  t=time.process_time_ns();n=z.ZSTD_compress(buf,cap,raw,len(raw),level);dt=time.process_time_ns()-t;assert not z.ZSTD_isError(n)
  out['encode'][str(f.with_suffix('.raw').relative_to(root))+'@'+str(level)]=[len(raw),n,dt]
Path('native-library.json').write_text(json.dumps(out,indent=2))
